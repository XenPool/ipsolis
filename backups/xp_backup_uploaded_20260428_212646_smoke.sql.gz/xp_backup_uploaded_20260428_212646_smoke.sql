-- ipSolis upload smoke-test
SELECT 1;
